# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['blacklight',
 'blacklight.autoML',
 'blacklight.autoML.tests',
 'blacklight.base',
 'blacklight.base.chromosomes',
 'blacklight.base.chromosomes.tests',
 'blacklight.base.individuals',
 'blacklight.base.individuals.tests',
 'blacklight.base.populations',
 'blacklight.base.utils',
 'blacklight.dataLoaders',
 'blacklight.dataLoaders.tests',
 'blacklight.dataLoaders.tests.data']

package_data = \
{'': ['*']}

install_requires = \
['html5lib', 'numpy', 'pandas']

extras_require = \
{':platform_machine != "arm64"': ['tensorflow']}

setup_kwargs = {
    'name': 'blacklight',
    'version': '0.1.1',
    'description': 'A package to manage genetic deep learning dependencies in python.',
    'long_description': '###### \nBlacklight  \n\n[![test](https://github.com/BlackLightLabs/blacklight/actions/workflows/test.yml/badge.svg?branch=main)](https://github.com/BlackLightLabs/blacklight/actions/workflows/test.yml) [![Codacy Badge](https://app.codacy.com/project/badge/Coverage/449f7ff90fcb4340a4c90884d15f700a)](https://www.codacy.com/gh/BlackLightLabs/blacklight/dashboard?utm_source=github.com&utm_medium=referral&utm_content=BlackLightLabs/blacklight&utm_campaign=Badge_Coverage) [![Codacy Badge](https://app.codacy.com/project/badge/Grade/449f7ff90fcb4340a4c90884d15f700a)](https://www.codacy.com/gh/BlackLightLabs/blacklight/dashboard?utm_source=github.com&amp;utm_medium=referral&amp;utm_content=BlackLightLabs/blacklight&amp;utm_campaign=Badge_Grade)\n\n# Genetic Deep Neural Net Topology Optimization\nThis project aims to use Genetic Algorithms to optimize the topologies of Deep Neural Networks (DNNs) and explore new possibilities that traditional optimization techniques might overlook. The fitness function of the algorithm is the accuracy of the model, and the genes represent the individual topologies.\n\n## Author\n\nThis project is developed and maintained by Cole Agard, with help from Brandon Lee. \n\n## Hypothesis\n\nThe hypothesis of this project is that DNN topologies will converge to either a local maximum or an absolute maximum over the evolution process, offering better performance than a DNN with randomly selected topology. For this experiment, the project will use equivalent activation functions (ReLU) and SGD for back-propagation, holding everything except the topology constant.\n\n## Methodology\n\nThe project utilizes a genetic algorithm to evolve the topology of the DNN. The algorithm starts with a randomly generated population of DNN topologies and evaluates their fitness using the accuracy of the model. The fittest individuals are selected for reproduction, while the weaker ones are discarded. The offspring of the selected individuals are then created through crossover and mutation. This process is repeated for a specified number of generations, and the best-performing topology is chosen as the final output.\n\n## Documentation \nDocumentation can be found at https://blacklightlabs.github.io/blacklight/html/index.html\n',
    'author': 'Cole Agard',
    'author_email': 'ctagard19@gmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'extras_require': extras_require,
    'python_requires': '>=3.9,<3.11',
}


setup(**setup_kwargs)
