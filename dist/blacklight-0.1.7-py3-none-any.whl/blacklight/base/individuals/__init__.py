from blacklight.base.individual import Individual
from .feed_forward_individual import FeedForwardIndividual

__all__ = [
    'FeedForwardIndividual',
    'Individual',
]
