from .feed_forward_chromosome import FeedForwardChromosome
from .base_chromosome import BaseChromosome
__all__ = [
    "FeedForwardChromosome",
    "BaseChromosome",
]
