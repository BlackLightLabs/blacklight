from ._feed_forward import FeedForward


__all__ = [
    'FeedForward',
]
