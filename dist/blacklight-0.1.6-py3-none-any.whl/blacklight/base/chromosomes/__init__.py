from .feed_forward_chromosome import FeedForwardChromosome
from blacklight.base.chromosome import BaseChromosome
__all__ = [
    "FeedForwardChromosome",
    "BaseChromosome"
]
